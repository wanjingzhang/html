'use strict';

var b = 1;

console.log(b);

var name = '张三';

console.log(name);

var c = '成功了么';

console.log(c);