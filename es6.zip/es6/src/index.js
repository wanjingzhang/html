let b=1;

console.log(b);

const name='张三';

console.log(name);

let c='成功了么';

console.log(c)